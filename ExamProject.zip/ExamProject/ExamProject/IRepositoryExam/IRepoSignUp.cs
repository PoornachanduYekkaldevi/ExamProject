﻿using ExamProject.entities;

namespace ExamProject.IRepositoryExam
{
    public interface IRepoSignUp
    {
        public List<SignUp> GetSignUps();
        public SignUp GetByIdSignUp(int id);
        public SignUp InsertSignUp(SignUp signUp);
        public SignUp UpdateSignUp(SignUp signUp);
        public SignUp DeleteSignUp(int id);
        public SignUp Login(string Email, string Password);
        public List<SignUp> GetAllTeachers();
    }
}
