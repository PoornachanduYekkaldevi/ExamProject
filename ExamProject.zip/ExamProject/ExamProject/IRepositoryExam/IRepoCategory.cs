﻿using ExamProject.entities;

namespace ExamProject.IRepositoryExam
{
    public interface IRepoCategory
    {
        public List<Category> GetCategories();
        public Category GetByIdCategories(int id);
        public Category InsertCategory(Category category);    
        public Category UpdateCategory(Category category);  
        public Category DeleteCategory(int id);
    }
}
