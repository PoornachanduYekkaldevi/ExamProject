﻿using ExamProject.entities;

namespace ExamProject.IRepositoryExam
{
    public interface IRepoQuestion
    {
        public List<Question> GetQuestions();
        public Question GetByIdQuestion(int id);
        public Question InsertQuestion(Question question);
        public Question UpdateQuestion(Question question);
        public Question DeleteQuestion(int id);
        public List<Question> GetAllQuestionsByCategoryId( int CategoryId );
    }
}
