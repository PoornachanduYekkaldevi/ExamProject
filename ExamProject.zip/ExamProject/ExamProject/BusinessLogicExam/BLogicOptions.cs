﻿using ExamProject.entities;
using ExamProject.IBusinessLogicExam;
using ExamProject.RepositoryExam;

namespace ExamProject.BusinessLogicExam
{
    public class BLogicOptions : ILogicOptions
    {

        RepoOptions repoOptions = new RepoOptions();
        public Option DeleteOption(int id)
        {
            return repoOptions.DeleteOption(id);
        }

        public Option GetByIdOption(int id)
        {
            return repoOptions.GetByIdOption(id);
        }

        public List<Option> GetOptions()
        {
            return repoOptions.GetOptions();
        }

        public Option InsertOption(Option Option)
        {
            return repoOptions.InsertOption(Option);
        }

        public Option UpdateOption(Option Option)
        {
            return repoOptions.UpdateOption(Option);
        }

        public List<Option> GetAllOptionsByQuestionId(int[] Question_Id)
        {
            return  repoOptions.GetAllOptionsByQuestionId(Question_Id);
        }

        public string InsertListOfOption(List<Option> options)
        {
            return repoOptions.InsertListOfOption(options);
        }
    }
}
