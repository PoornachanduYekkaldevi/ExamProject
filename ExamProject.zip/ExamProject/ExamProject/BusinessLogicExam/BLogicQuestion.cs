﻿using ExamProject.entities;
using ExamProject.IBusinessLogicExam;
using ExamProject.RepositoryExam;

namespace ExamProject.BusinessLogicExam
{
    public class BLogicQuestion : ILogicQuestions
    {

        RepoQuestion repoquestion = new RepoQuestion();
        public Question DeleteQuestion(int id)
        {
            return repoquestion.DeleteQuestion(id);
        }

        public Question GetByIdQuestion(int id)
        {
            return repoquestion.GetByIdQuestion(id);
        }

        public List<Question> GetQuestions()
        {
            return repoquestion.GetQuestions();
        }

        public Question InsertQuestion(Question Question)
        {
            return repoquestion.InsertQuestion(Question);
        }

        public Question UpdateQuestion(Question Question)
        {
            return repoquestion.UpdateQuestion(Question);
        }

        public List<Question> GetAllQuestionsByCategoryId(int CategoryId)
        {
            return repoquestion.GetAllQuestionsByCategoryId(CategoryId);
        }
    }
}
