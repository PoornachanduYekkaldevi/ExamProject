﻿using ExamProject.entities;
using ExamProject.IBusinessLogicExam;
using ExamProject.RepositoryExam;

namespace ExamProject.BusinessLogicExam
{
    public class BLogicSignUp : ILogicSignUp
    {

        RepoSignUp repoSignUp = new RepoSignUp();
        public  SignUp DeleteSignUp(int id)
        {
            return repoSignUp.DeleteSignUp(id);
        }

        public SignUp GetByIdSignUp(int id)
        {
            return repoSignUp.GetByIdSignUp(id);
        }

        public List<SignUp> GetSignUps()
        {
            return repoSignUp.GetSignUps();
        }

        public SignUp InsertSignUp(SignUp SignUp)
        {
            return repoSignUp.InsertSignUp(SignUp);
        }

        public SignUp Login(string Email, string Password)
        {
           return repoSignUp.Login(Email, Password);
        }

        public SignUp UpdateSignUp(SignUp SignUp)
        {
            return repoSignUp.UpdateSignUp(SignUp);
        }

        public List<SignUp> GetAllTeachers()
        {
            return repoSignUp.GetAllTeachers();
        }

    }
}
