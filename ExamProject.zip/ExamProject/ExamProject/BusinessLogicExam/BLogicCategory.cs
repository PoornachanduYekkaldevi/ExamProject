﻿using ExamProject.entities;
using ExamProject.IBusinessLogicExam;
using ExamProject.RepositoryExam;

namespace ExamProject.BusinessLogicExam
{
    public class BLogicCategory : ILogicCategory
    {
        RepoCetagory repoCetagory = new RepoCetagory();
        public Category DeleteCategory(int id)
        {
            return repoCetagory.DeleteCategory(id);
        }

        public Category GetByIdCategories(int id)
        {
            return repoCetagory.GetByIdCategories(id);
        }

        public List<Category> GetCategories()
        {
            return repoCetagory.GetCategories();
        }

        public Category InsertCategory(Category category)
        {
            return repoCetagory.InsertCategory(category);
        }

        public Category UpdateCategory(Category category)
        {
            return repoCetagory.UpdateCategory(category);
        }
    }
}
