﻿using ExamProject.entities;
using ExamProject.IRepositoryExam;

namespace ExamProject.RepositoryExam
{
    public class RepoSignUp : IRepoSignUp
    {
        ExamsContext context = new ExamsContext();
        public SignUp DeleteSignUp(int id)
        {
            try
            {
                var data = context.SignUps.Where(a => a.Id == id).FirstOrDefault();
                context.SignUps.Remove(data);
                context.SaveChanges();
                return data;
            }
            catch(Exception ex)
            {
                return null;
            }
           
        }

        public SignUp GetByIdSignUp(int id)
        {
            var data = context.SignUps.Where(a => a.Id == id).FirstOrDefault();
            return data;
        }

        public List<SignUp> GetSignUps()
        {
            return context.SignUps.ToList();
        }

        public SignUp InsertSignUp(SignUp signUp)
        {
            try
            {
                if (signUp.Username == null)
                {
                    return signUp;
                }
                else
                {
                    context.SignUps.Add(signUp);
                    context.SaveChanges();
                    return signUp;
                }
            }
            catch (Exception ex)
            {
                return signUp;
            }

        }

        public SignUp Login(string Email, string Password)
        {
            try
            {
                var data = context.SignUps.Where(a => a.Email == Email && a.Password == Password).FirstOrDefault();

                if (data == null)
                {
                    return data;
                }
                else if(data.Id > 0)
                {
                    return data;
                }
                else
                {
                    return data;
                }
            }
            catch(Exception ex)
            {
                return null;
            }


        }

        public SignUp UpdateSignUp(SignUp signUp)
        {
            try
            {
                context.SignUps.Update(signUp);
                context.SaveChanges();
                return signUp;
            }
            catch (Exception ex)
            {
                return signUp= null;
            }
        }
        public List<SignUp> GetAllTeachers()
        {
           return  context.SignUps.Where(a=>a.Teacher == true).ToList();

        }


    }
}
