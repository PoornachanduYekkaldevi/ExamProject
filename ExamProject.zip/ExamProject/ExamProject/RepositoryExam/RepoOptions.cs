﻿using ExamProject.entities;
using ExamProject.IRepositoryExam;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;

namespace ExamProject.RepositoryExam
{
    public class RepoOptions : IRepoOptions
    {

        ExamsContext context = new ExamsContext();
        public Option DeleteOption(int id)
        {
            var data = context.Options.Where(a => a.Id == id).FirstOrDefault();
            context.Options.Remove(data);
            context.SaveChanges();
            return data;
        }

        public Option GetByIdOption(int id)
        {
            var data = context.Options.Where(a => a.Id == id).FirstOrDefault();
            return data;
        }

        public List<Option> GetOptions()
        {
            return context.Options.ToList();
        }

        public Option InsertOption(Option option)
        {
            try
            {
                context.Options.Add(option);
                context.SaveChanges();
                return option;
            }
            catch (Exception ex)
            {
                return option;
            }

        }

        public Option UpdateOption(Option option)
        {
            try
            {
                context.Options.Update(option);
                context.SaveChanges();
                return option;
            }
            catch (Exception ex)
            {
                return option;
            }
        }


        //public List<Option> GetAllOptionsByQuestionId(List<OptionList> listOptions)
        //{
        //    List<Option> result = new List<Option>();
        //    foreach (var optionList in listOptions)
        //    {
        //        var data = context.Options.Where(a => a.QuestionId == optionList.Question_Id).ToList();
        //        result.AddRange(data); // Adding all items to the result list
        //    }

        //    return result;
        //}




        public List<Option> GetAllOptionsByQuestionId(int[] Question_Id )
        {
            List<Option> result = new List<Option>();
            foreach (var optionList in Question_Id)
            {
                var data = context.Options.Where(a => a.QuestionId == optionList).ToList();
                result.AddRange(data); // Adding all items to the result list
            }

            return result;
        }



        public string InsertListOfOption( List<Option> options)
        {
            try
            {
                foreach (var data in options)
                {
                    context.Options.Add(data );
                    context.SaveChanges();
                }
                return "ok";
            }
            catch (Exception ex)
            {
                // Log the exception here for debugging purposes
                // e.g., logger.LogError(ex, "An error occurred while inserting options");
                return "no";
            }
        }

    }
}
