﻿using ExamProject.entities;
using ExamProject.IRepositoryExam;

namespace ExamProject.RepositoryExam
{
    public class RepoCetagory : IRepoCategory
    {
            ExamsContext context = new ExamsContext();
            public Category DeleteCategory(int id)
            {
                var data = context.Categories.Where(a=>a.Id == id).FirstOrDefault();
                context.Categories.Remove(data);
                context.SaveChanges();
                return data;
            }

            public Category GetByIdCategories(int id)
            {
                var data = context.Categories.Where(a => a.Id == id).FirstOrDefault();
                return data;
            }

            public List<Category> GetCategories()
            {
                return context.Categories.ToList();
            }

            public   Category InsertCategory(Category category)
            {
                try
                {
                    context.Categories.Add(category);
                    context.SaveChanges();
                    return  category;
                }
                catch(Exception ex)
                {
                    return  category;
                }
           
            }

            public Category UpdateCategory(Category category)
            {
                try
                {
                    context.Categories.Update(category);
                    context.SaveChanges();
                    return category;
                }
                catch(Exception ex)
                {
                    return category;
                }
            }
    }
}
