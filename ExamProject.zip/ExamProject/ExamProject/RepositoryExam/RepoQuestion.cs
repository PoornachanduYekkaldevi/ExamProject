﻿using ExamProject.entities;
using ExamProject.IRepositoryExam;

namespace ExamProject.RepositoryExam
{
    public class RepoQuestion : IRepoQuestion
    {
        ExamsContext context = new ExamsContext();
        public Question DeleteQuestion(int id)
        {
            var data = context.Questions.Where(a => a.Id == id).FirstOrDefault();
            context.Questions.Remove(data);
            context.SaveChanges();
            return data;
        }

        public Question GetByIdQuestion(int id)
        {
            var data = context.Questions.Where(a => a.Id == id).FirstOrDefault();
            return data;
        }

        public List<Question> GetQuestions()
        {
            return context.Questions.ToList();
        }

        public Question InsertQuestion(Question question)
        {
            try
            {
                if(question.Question1 != null)
                {
                    context.Questions.Add(question);
                    context.SaveChanges();
                    return question;
                }
                else
                {
                    return question;
                }
               
            }
            catch (Exception ex)
            {
                return question;
            }

        }

        public Question UpdateQuestion(Question question)
        {
            try
            {
                context.Questions.Update(question);
                context.SaveChanges();
                return question;
            }
            catch (Exception ex)
            {
                return question;
            }
        }

        public List<Question> GetAllQuestionsByCategoryId(int CategoryId)
        {
            var data =  context.Questions.Where(a=>a.CategoryId == CategoryId).ToList();
            return  data;
        }
    }
}
