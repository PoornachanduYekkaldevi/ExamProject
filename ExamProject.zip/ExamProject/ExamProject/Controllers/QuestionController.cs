﻿using ExamProject.BusinessLogicExam;
using ExamProject.entities;
using ExamProject.RepositoryExam;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace ExamProject.Controllers
{
    [EnableCors]
    [Route("api/[controller]")]
    [ApiController]
    public class QuestionController : ControllerBase
    {

        BLogicQuestion logicquestion = new BLogicQuestion();

        [Route("api/DeleteQuestion/{id}")]
        [HttpDelete]
        public Question DeleteQuestion(int id)
        {
            return logicquestion.DeleteQuestion(id);
        }

        [Route("api/GetByIdQuestion/{id}")]
        [HttpGet]
        public Question GetByIdQuestion(int id)
        {
            return logicquestion.GetByIdQuestion(id);
        }

        [Route("api/GetQuestions")]
        [HttpGet]
        public List<Question> GetQuestions()
        {
            return logicquestion.GetQuestions();
        }

        [Route("api/InsertQuestion")]
        [HttpPost]
        public Question InsertQuestion(Question Question)
        {
            return logicquestion.InsertQuestion(Question);
        }

        [Route("api/UpdateQuestion")]
        [HttpPut]
        public Question UpdateQuestion(Question Question)
        {
            return logicquestion.UpdateQuestion(Question);
        }

        [Route("api/GetAllQuestionsByCategoryId/{CategoryId}")]
        [HttpGet]
        public List<Question> GetAllQuestionsByCategoryId(int CategoryId)
        {
            return logicquestion.GetAllQuestionsByCategoryId( CategoryId);
        }
    }
}
