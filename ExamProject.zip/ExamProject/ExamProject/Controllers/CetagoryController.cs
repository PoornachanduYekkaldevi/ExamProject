﻿using ExamProject.BusinessLogicExam;
using ExamProject.entities;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace ExamProject.Controllers
{
    [EnableCors]
    [Route("api/[controller]")]
    [ApiController]
    public class CetagoryController : ControllerBase
    {


        BLogicCategory LogicCategory = new BLogicCategory();

        [Route("api/GetCategory")]
        [HttpGet]
        public List<Category> GetCategory()
        {
            return LogicCategory.GetCategories();
        }

        [Route("api/GetByIdCategories/{id}")]
        [HttpGet]
        public Category GetByIdCategories(int id) 
        {
            return LogicCategory.GetByIdCategories(id);
        }

        [Route("api/InsertCategory")]
        [HttpPost]
        public Category InsertCategory(Category category)
        {
            return  LogicCategory.InsertCategory(category);
        }

        [Route("api/UpdateCategory")]
        [HttpPut]
        public Category UpdateCategory(Category category)
        {
            return LogicCategory.UpdateCategory(category);
        }

        [Route("api/DeleteCategory/{id}")]
        [HttpDelete]
        public Category DeleteCategory(int id)
        {
            return LogicCategory.DeleteCategory(id);
        }
    }
}
