﻿using ExamProject.BusinessLogicExam;
using ExamProject.entities;
using ExamProject.IRepositoryExam;
using ExamProject.RepositoryExam;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace ExamProject.Controllers
{
    [EnableCors]
    [Route("api/[controller]")]
    [ApiController]
    public class SignUpController : ControllerBase
    {

        BLogicSignUp logicSignUp = new BLogicSignUp();

        [Route("api/DeleteSignUp/{id}")]
        [HttpDelete]
        public SignUp DeleteSignUp(int id)
        {
            return logicSignUp.DeleteSignUp(id);
        }

        [Route("api/GetByIdSignUp/{id}")]
        [HttpGet]
        public SignUp GetByIdSignUp(int id)
        {
            return logicSignUp.GetByIdSignUp(id);
        }

        [Route("api/GetSignUps")]
        [HttpGet]
        public List<SignUp> GetSignUps()
        {
            return logicSignUp.GetSignUps();
        }

        [Route("api/InsertSignUp")]
        [HttpPost]
        public SignUp InsertSignUp(SignUp signUp)
        {
       
                return logicSignUp.InsertSignUp(signUp);
            
        }

        [Route("api/UpdateSignUp")]
        [HttpPut]
        public SignUp UpdateSignUp(SignUp SignUp)
        {
            try
            {

            if(SignUp.Id >0 )
            {
                return logicSignUp.UpdateSignUp(SignUp);

            }
            else
            {
                return null;
            }
            }
            catch(Exception ex)
            {
                return null;
            }
        }

        [Route("api/Login/{Email}/{Password}")]
        [HttpGet]
        public SignUp Login(string Email, string Password)
        {
            return logicSignUp.Login(Email, Password);
        }

        [Route("api/GetAllTeachers")]
        [HttpGet]
        public List<SignUp> GetAllTeachers()
        {
            return logicSignUp.GetAllTeachers();
        }


    }
}
