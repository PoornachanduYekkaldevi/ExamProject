﻿using ExamProject.BusinessLogicExam;
using ExamProject.entities;
using ExamProject.IRepositoryExam;
using ExamProject.RepositoryExam;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace ExamProject.Controllers
{
    [EnableCors]
    [Route("api/[controller]")]
    [ApiController]
    public class OptionController : ControllerBase
    {
        BLogicOptions LogicOption = new BLogicOptions();

        [Route("api/GetOption")]
        [HttpGet]
        public List<Option> GetOption()
        {
            return LogicOption.GetOptions();
        }

        [Route("api/GetByIdOption/{id}")]
        [HttpGet]
        public Option GetByIdOption(int id)
        {
            return LogicOption.GetByIdOption(id);
        }

        [Route("api/InsertOption")]
        [HttpPost]
        public Option InsertOption(Option Option)
        {
            return LogicOption.InsertOption(Option);
        }

        [Route("api/UpdateOption")]
        [HttpPut]
        public Option UpdateOption(Option Option)
        {
            return LogicOption.UpdateOption(Option);
        }

        [Route("api/DeleteOption/{id}")]
        [HttpDelete]
        public Option DeleteOption(int id)
        {
            return LogicOption.DeleteOption(id);
        }

        [Route("api/GetAllOptionsByQuestionId")]
        [HttpPost]
        public List<Option> GetAllOptionsByQuestionId(int[] Question_Id)
        {
            return LogicOption.GetAllOptionsByQuestionId(Question_Id);
        }

        [Route("api/InsertListOfOption")]
        [HttpPost]
        public string InsertListOfOption(List<Option> options)
        {
            return LogicOption.InsertListOfOption(options);
        }
    }
}
