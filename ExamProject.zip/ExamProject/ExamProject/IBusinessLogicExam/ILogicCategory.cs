﻿using ExamProject.entities;

namespace ExamProject.IBusinessLogicExam
{
    public interface ILogicCategory
    {
        public List<Category> GetCategories();
        public Category GetByIdCategories(int id);
        public Category InsertCategory(Category category);
        public Category UpdateCategory(Category category);
        public Category DeleteCategory(int id);
    }
}
