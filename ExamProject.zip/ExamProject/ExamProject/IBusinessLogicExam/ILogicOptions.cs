﻿using ExamProject.entities;

namespace ExamProject.IBusinessLogicExam
{
    public interface ILogicOptions
    {
        public List<Option> GetOptions();
        public Option GetByIdOption(int id);
        public Option InsertOption(Option option);
        public Option UpdateOption(Option option);
        public Option DeleteOption(int id);
        public List<Option> GetAllOptionsByQuestionId(int[] Question_Id);
        public string InsertListOfOption(List<Option> options);


    }
}
