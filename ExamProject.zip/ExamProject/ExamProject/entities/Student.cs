﻿using System;
using System.Collections.Generic;

namespace ExamProject.entities
{
    public partial class Student
    {
        public int Id { get; set; }
        public string? StudentIdCard { get; set; }
        public string? FirstName { get; set; }
        public string? LastName { get; set; }
        public string? GradientName { get; set; }
        public int? Gender { get; set; }
        public DateTime? DateOfBirth { get; set; }
        public int? CourseYear { get; set; }
        public int? Course { get; set; }
        public bool? IsDeleted { get; set; }

        public virtual LookUp? CourseNavigation { get; set; }
        public virtual LookUp? CourseYearNavigation { get; set; }
        public virtual LookUp? GenderNavigation { get; set; }
    }
}
