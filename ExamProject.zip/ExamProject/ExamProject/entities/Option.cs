﻿using System;
using System.Collections.Generic;

namespace ExamProject.entities
{
    public partial class Option
    {
        public int Id { get; set; }
        public int? QuestionId { get; set; }
        public string? Options { get; set; }
        public bool? AnswerValue { get; set; }

        public virtual Question? Question { get; set; }
    }
}
