﻿using System;
using System.Collections.Generic;

namespace ExamProject.entities
{
    public partial class LookUpValue
    {
        public int Id { get; set; }
        public int? ParentId { get; set; }
        public string? Name { get; set; }
        public bool? IsDeleted { get; set; }

        public virtual LookUp? Parent { get; set; }
    }
}
