﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace ExamProject.entities
{
    public partial class ExamsContext : DbContext
    {
        public ExamsContext()
        {
        }

        public ExamsContext(DbContextOptions<ExamsContext> options)
            : base(options)
        {
        }

        public virtual DbSet<Category> Categories { get; set; } = null!;
        public virtual DbSet<LookUp> LookUps { get; set; } = null!;
        public virtual DbSet<LookUpValue> LookUpValues { get; set; } = null!;
        public virtual DbSet<Option> Options { get; set; } = null!;
        public virtual DbSet<Question> Questions { get; set; } = null!;
        public virtual DbSet<SignUp> SignUps { get; set; } = null!;
        public virtual DbSet<Student> Students { get; set; } = null!;

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see http://go.microsoft.com/fwlink/?LinkId=723263.
                optionsBuilder.UseSqlServer("Server=DESKTOP-NEHRSOO;Database=Exams;Trusted_Connection=True;");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Category>(entity =>
            {
                entity.ToTable("category");

                entity.Property(e => e.Categorys)
                    .HasMaxLength(250)
                    .IsUnicode(false)
                    .HasColumnName("categorys");
            });

            modelBuilder.Entity<LookUp>(entity =>
            {
                entity.ToTable("LookUp");

                entity.Property(e => e.Caterogy)
                    .HasMaxLength(200)
                    .IsUnicode(false);

                entity.Property(e => e.Code)
                    .HasMaxLength(200)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<LookUpValue>(entity =>
            {
                entity.ToTable("LookUpValue");

                entity.Property(e => e.Name)
                    .HasMaxLength(200)
                    .IsUnicode(false);

                entity.Property(e => e.ParentId).HasColumnName("Parent_Id");

                entity.HasOne(d => d.Parent)
                    .WithMany(p => p.LookUpValues)
                    .HasForeignKey(d => d.ParentId)
                    .HasConstraintName("FK__LookUpVal__Paren__619B8048");
            });

            modelBuilder.Entity<Option>(entity =>
            {
                entity.Property(e => e.AnswerValue).HasColumnName("Answer_Value");

                entity.Property(e => e.Options).IsUnicode(false);

                entity.Property(e => e.QuestionId).HasColumnName("Question_Id");

                entity.HasOne(d => d.Question)
                    .WithMany(p => p.Options)
                    .HasForeignKey(d => d.QuestionId)
                    .HasConstraintName("FK__Options__Questio__5629CD9C");
            });

            modelBuilder.Entity<Question>(entity =>
            {
                entity.Property(e => e.CategoryId).HasColumnName("category_Id");

                entity.Property(e => e.Question1)
                    .HasMaxLength(250)
                    .IsUnicode(false)
                    .HasColumnName("Question");

                entity.HasOne(d => d.Category)
                    .WithMany(p => p.Questions)
                    .HasForeignKey(d => d.CategoryId)
                    .HasConstraintName("FK__Questions__categ__5070F446");
            });

            modelBuilder.Entity<SignUp>(entity =>
            {
                entity.ToTable("SignUp");

                entity.Property(e => e.ConfirmPassword)
                    .HasMaxLength(100)
                    .IsUnicode(false)
                    .HasColumnName("Confirm_Password");

                entity.Property(e => e.Email)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.Password)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.Username)
                    .HasMaxLength(100)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<Student>(entity =>
            {
                entity.Property(e => e.DateOfBirth).HasColumnType("date");

                entity.Property(e => e.FirstName)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.GradientName)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.LastName)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.StudentIdCard)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.HasOne(d => d.CourseNavigation)
                    .WithMany(p => p.StudentCourseNavigations)
                    .HasForeignKey(d => d.Course)
                    .HasConstraintName("FK__Students__Course__66603565");

                entity.HasOne(d => d.CourseYearNavigation)
                    .WithMany(p => p.StudentCourseYearNavigations)
                    .HasForeignKey(d => d.CourseYear)
                    .HasConstraintName("FK__Students__Course__656C112C");

                entity.HasOne(d => d.GenderNavigation)
                    .WithMany(p => p.StudentGenderNavigations)
                    .HasForeignKey(d => d.Gender)
                    .HasConstraintName("FK__Students__Gender__6477ECF3");
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
