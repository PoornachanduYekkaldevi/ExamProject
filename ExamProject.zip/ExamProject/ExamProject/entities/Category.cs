﻿using System;
using System.Collections.Generic;

namespace ExamProject.entities
{
    public partial class Category
    {
        public Category()
        {
            Questions = new HashSet<Question>();
        }

        public int Id { get; set; }
        public string? Categorys { get; set; }

        public virtual ICollection<Question> Questions { get; set; }
    }
}
