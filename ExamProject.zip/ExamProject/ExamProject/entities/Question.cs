﻿using System;
using System.Collections.Generic;

namespace ExamProject.entities
{
    public partial class Question
    {
        public Question()
        {
            Options = new HashSet<Option>();
        }

        public int Id { get; set; }
        public int? CategoryId { get; set; }
        public string? Question1 { get; set; }

        public virtual Category? Category { get; set; }
        public virtual ICollection<Option> Options { get; set; }
    }
}
