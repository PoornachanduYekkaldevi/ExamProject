﻿using System;
using System.Collections.Generic;

namespace ExamProject.entities
{
    public partial class LookUp
    {
        public LookUp()
        {
            LookUpValues = new HashSet<LookUpValue>();
            StudentCourseNavigations = new HashSet<Student>();
            StudentCourseYearNavigations = new HashSet<Student>();
            StudentGenderNavigations = new HashSet<Student>();
        }

        public int Id { get; set; }
        public string? Caterogy { get; set; }
        public string? Code { get; set; }
        public bool? IsDeleted { get; set; }

        public virtual ICollection<LookUpValue> LookUpValues { get; set; }
        public virtual ICollection<Student> StudentCourseNavigations { get; set; }
        public virtual ICollection<Student> StudentCourseYearNavigations { get; set; }
        public virtual ICollection<Student> StudentGenderNavigations { get; set; }
    }
}
